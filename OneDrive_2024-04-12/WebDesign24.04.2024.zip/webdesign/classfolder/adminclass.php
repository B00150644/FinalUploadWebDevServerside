<?php
class Admin extends User {
    public function __construct($connection) {
        parent::__construct($connection);
    }

   
}
?>