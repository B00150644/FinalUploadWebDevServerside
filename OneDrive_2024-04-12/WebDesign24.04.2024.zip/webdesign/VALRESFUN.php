<?php 

// Include the database connection parameters
require 'connection.php';

require 'classfolder/Tables.php'; 
require 'classfolder/SetMenu.php';
require 'classfolder/Payments.php';

class Reservations{
    private $conn;
    
    public function __construct($connection) {
        $this->conn = $connection->getConnection();
    }

    public function handleFormSubmission() {
        // Form submission handling
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            try {
                // Simulate form data for payment insertion testing
                $_POST['3course'] = 2; // Simulate selecting 2x 3-course meals
                $_POST['2course'] = 1; // Simulate selecting 1x 2-course meal
                $_POST['kids'] = 0;    // Simulate not selecting any kids meal
                $_POST['number'] = 4;   // Simulate reservation for 4 people
                $_POST['date'] = '2024-04-21'; // Simulate reservation date
                $_POST['time'] = '18:30';      // Simulate reservation time
                $_POST['cardType'] = 'Mastercard'; // Simulate card type
                $_POST['cardNo'] = '1111-2222-3333-4444'; // Simulate card number
                $_POST['cardName'] = 'John More Doe';    // Simulate cardholder name

                // Create an instance of the Reservations class
                $reservation = new Reservations(new Connection($servername, $username_db, $password_db, $database_name));

                // Handle form submission
                $reservation->handleFormSubmission();
            } catch (Exception $e) {
                // Handle exceptions
                echo "Error: " . $e->getMessage();
            }
        }
    }

    // Method for testing payment insertion
    public function testPaymentInsertion() {
        try {
            // Create an instance of the Reservations class
            $reservation = new Reservations(new Connection($servername, $username_db, $password_db, $database_name));

            // Handle form submission
            $reservation->handleFormSubmission();
        } catch (Exception $e) {
            // Handle exceptions
            echo "Error: " . $e->getMessage();
        }
    }

    // Other methods for table availability check, calculating total price, etc. remain the same...
}
?>