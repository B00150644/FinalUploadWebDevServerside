<?php
require 'connection.php'; 

try {
    // Find the maximum AccountNo currently in use
    $sql_max_account = "SELECT MAX(AccountNo) AS max_account FROM customer";
    $stmt_max_account = $conn->query($sql_max_account);
    $row_max_account = $stmt_max_account->fetch(PDO::FETCH_ASSOC);
    $next_account_no = ($row_max_account["max_account"] !== null) ? $row_max_account["max_account"] + 1 : 1;

    // Find the maximum SessionID currently in use
    $sql_max_session = "SELECT MAX(SessionID) AS max_session FROM user";
    $stmt_max_session = $conn->query($sql_max_session);
    $row_max_session = $stmt_max_session->fetch(PDO::FETCH_ASSOC);
    $next_session_id = ($row_max_session["max_session"] !== null) ? $row_max_session["max_session"] + 1 : 1;

    // Form submission handling
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Validate form data (you should add more validation as needed)
        $name = $_POST["name"];
        $number = $_POST["number"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $username = $_POST["username"];

        // Insert data into database for user table
        $user_sql = "INSERT INTO user (username, password, SessionID) VALUES (?, ?, ?)";
        $stmt_user = $conn->prepare($user_sql);
        $stmt_user->execute([$username, $password, $next_session_id]);

        // Insert data into database for customer table
        $customer_sql = "INSERT INTO customer (AccountNo, Name, Email, PhoneNo, SessionID_fk2) VALUES (?, ?, ?, ?, ?)";
        $stmt_customer = $conn->prepare($customer_sql);
        $stmt_customer->execute([$next_account_no, $name, $email, $number, $next_session_id]);

        //succes message
        echo '<div class="success-message">New user record created successfully</div>';

        
        echo '<div class="success-message">New record created successfully</div>';
        // Increment the next AccountNo for the next insertion
        $next_account_no++;
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}

$conn = null; // Close connection
?>
