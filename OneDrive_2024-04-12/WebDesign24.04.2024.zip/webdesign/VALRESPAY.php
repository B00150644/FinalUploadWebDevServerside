<?php
require 'VALRESFUN.php'; // Include the file containing the Reservations class
require 'connection.php'; // Include the file containing database connection details

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        // Create a new instance of the Reservations class
        $reservations = new Reservations(new Connection($servername, $username_db, $password_db, $database_name));

        // Handle form submission (testing payment insertion)
        $reservations->handleFormSubmission();
    } catch (Exception $e) {
        // Display error message
        echo "Error: " . $e->getMessage();
    }
}
?>

<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
    <h2>Test Payment Insertion</h2>
    
    <label for="cardType">Card Type</label>
    <input type="text" id="cardType" name="cardType" placeholder="Mastercard">

    <label for="cardNo">Card Number</label>
    <input type="text" id="cardNo" name="cardNo" placeholder="1111-2222-3333-4444">

    <label for="cardName">Card Name</label>
    <input type="text" id="cardName" name="cardName" placeholder="John More Doe">

    <button type="submit" name="submit">Test Payment Insertion</button>
</form>
