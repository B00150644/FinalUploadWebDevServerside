<?php 
require 'Templates/Header.php'; // Include header template if necessary
?>
<?php
// Include dependencies
require 'connection.php';
require 'classfolder/AccountReservationClass.php'; 
require 'classfolder/customer.php'; // Assuming Customer class is defined in Customer.php

// Instantiate the Customer class
$customer = new Customer($connection); // Assuming $connection is defined in connection.php

// Call the customerInfo method to fetch customer data
$customerData = $customer->customerInfo();

// Output or use the customer data
if (!empty($customerData)) {
    foreach ($customerData as $customerInfo) {
        // Print customer information
        echo "Customer Information:<br>";
        echo "Customer Number: " . $customerInfo['AccountNo'] . "<br>";
        echo "Name: " . $customerInfo['Name'] . "<br>";
        echo "Phone Number: " . $customerInfo['PhoneNo'] . "<br>";
        echo "Email: " . $customerInfo['Email'] . "<br>";
        echo "Username: " . $customerInfo['UserName'] . "<br>";
        echo "<br>";
    }
} else {
    echo "No customer data found.";
}

// Instantiate the AccountReservation class
$reservation = new AccountReservation($connection); // Assuming $connection is defined in connection.php

// Call the getAccountReservations method to fetch reservation data
$reservationData = $reservation->getAccountReservations();

// Output or use the reservation data
if (!empty($reservationData)) {
    echo "Reservation Information:<br>";
    foreach ($reservationData as $reservationInfo) {
        // Print reservation information
        echo "Reservation ID: " . $reservationInfo['ReservationID'] . "<br>";
        echo "Date: " . $reservationInfo['Date'] . "<br>";
        echo "Time: " . $reservationInfo['Time'] . "<br>";
        echo "Guest No: " . $reservationInfo['GuestNo'] . "<br>";
        echo "Attendence: " . $reservationInfo['Attendence'] . "<br>";
        echo "Cancelled: " . $reservationInfo['Cancelled'] . "<br>";
        echo "Account Number: " . $reservationInfo['AccountNo_fk'] . "<br>";
        echo "Table ID: " . $reservationInfo['TableID_FK'] . "<br>";
        echo "Admin ID: " . $reservationInfo['adminID_fk2'] . "<br>";
        echo "<br>";
    }
} else {
    echo "No reservation data found.";
}
?>
