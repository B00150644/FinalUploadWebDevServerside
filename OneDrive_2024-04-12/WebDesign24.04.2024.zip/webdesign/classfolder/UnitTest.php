<?php
require 'Payments.php';
require 'Tables.php';

// This is a Unit Test for the Payments Class 
$payment1 = new Payments();
$payment2 = new Payments();

// First Payment Test
$payment1->setTotal('45');
$payment1->setCardNo('1111-2222-3333-4444');
$payment1->setCardName("John Doe");
$payment1->setCardType("Visa");

// Second Payment Test
$payment2->setTotal('1050');
$payment2->setCardNo('1111222233334444');
$payment2->setCardName("Jane Smith");
$payment2->setCardType("MasterCard");

$payment1->displayPayments();
$payment2->displayPayments();

// This is a Unit Test for the Tables Class 
$table1 = new Tables();
$table2 = new Tables();

// First Table Test
$table1->setTableID('5');
$table1->setTableSize('10');
$table1->setTableAvailability("True");

// Second Table Test
$table2->setTableID('1000000');
$table2->setTableSize('0');
$table2->setTableAvailability("False");

$table1->displayTables();
$table2->displayTables();
?>
<?php
require '../connection.php'; 
require 'usermethod.php';
echo "Unit Test User:" . "<br>" . "<br>";
echo "This is to validate the User information and displays each row from the database:" . "<br>" . "<br>";
$userHandler = new UserHandler($connection); // UserHandler class with database connection

$users = $userHandler->getUsers(); // Call the getUsers function to retrieve users

foreach ($users as $user) { // Display user information
    echo "Username: " . $user->getUserName() . ", SessionID: " . $user->getSessionId() . ", Password: " . $user->getPassword() . "<br>";
}

$connection->closeConnection();


echo "Unit Test Menu :" . "<br>" . "<br>";
echo "This is to validate the Menu information and displays each row from the database:" . "<br>" . "<br>";
require 'menumethodtest.php';

$menuHandler = new MenuHandler($connection);

$menuItems = $menuHandler->getMenuItems();

foreach ($menuItems as $menuItem) {
    echo "MenuID: " . $menuItem->getMenuId() . ", ProductName: " . $menuItem->getProductName() . ", AdminID: " . $menuItem->getAdminId() . "<br>";
}

$connection->closeConnection();
?>
