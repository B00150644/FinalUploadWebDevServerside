<?php
require 'customer.php'; // Include the CustomerHandler class

// Instantiate the CustomerHandler class with your database connection
$customerHandler = new CustomerHandler($connection); // Assuming $connection is your database connection variable

// Call the getCustomers() method to retrieve customer data
$customers = $customerHandler->getCustomers();

// Output the customer data
echo '<pre>';
print_r($customers);
echo '</pre>';
?>
