<?php
require_once 'classfolder/session.php';
$session = new session();
$session->forgetSession();
?>